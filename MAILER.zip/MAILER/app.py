from flask import Flask, request, redirect, url_for, render_template
import pandas as pd
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

app = Flask(__name__)

# Replace with your actual SMTP server details
SMTP_SERVER = 'smtp.example.com'
SMTP_PORT = 587
SMTP_USERNAME = 'dshreyasi3003@gmail.com'
SMTP_PASSWORD = 'ujntayukwllonuwx'

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/send_emails', methods=['POST'])
def send_emails():
    if 'file' not in request.files:
        return redirect(request.url)
    
    file = request.files['file']
    subject = request.form['subject']
    message = request.form['message']
    
    if file and file.filename.endswith('.xlsx'):
        # Read the Excel file
        df = pd.read_excel(file)
        emails = df['Email'].tolist()
        
        # Create a connection to the SMTP server
        server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
        server.starttls()
        server.login(SMTP_USERNAME, SMTP_PASSWORD)
        
        for email in emails:
            msg = MIMEMultipart()
            msg['From'] = SMTP_USERNAME
            msg['To'] = email
            msg['Subject'] = subject
            
            msg.attach(MIMEText(message, 'plain'))
            
            server.sendmail(SMTP_USERNAME, email, msg.as_string())
        
        server.quit()
        
        return 'Emails sent successfully!'
    
    return 'Invalid file format. Please upload an Excel file.'

if __name__ == '__main__':
    app.run(debug=True)
