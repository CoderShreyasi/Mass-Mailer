 
from flask import Flask, request, render_template  
from flask_wtf import FlaskForm  
from wtforms import StringField, FileField, TextAreaField  
from wtforms.validators import DataRequired  
from openpyxl import load_workbook  
import smtplib  

from email.mime.text import MIMEText  
from email.mime.multipart import MIMEMultipart  
  
app = Flask(__name__)  
app.config['SECRET_KEY'] = '9b9fb9a8099237260a9ce294a5b5707f'  
  
class EmailForm(FlaskForm):  
  sender_email = StringField('Sender Email', validators=[DataRequired()])  
  subject = StringField('Subject', validators=[DataRequired()])  
  message = TextAreaField('Message', validators=[DataRequired()])  
  excel_file = FileField('Excel File', validators=[DataRequired()])  
  
@app.route('/', methods=['GET', 'POST'])  
def index():  
  form = EmailForm()  
  if form.validate_on_submit():  
    sender_email = form.sender_email.data  
    subject = form.subject.data 
    message = form.message.data  
    excel_file = form.excel_file.data  
    recipients = read_recipients_from_excel(excel_file)  
    send_emails(sender_email, subject, message, recipients)  
    return 'Emails sent successfully!'  
  return render_template('index.html', form=form)  
  
def read_recipients_from_excel(excel_file):  
  wb = load_workbook(excel_file)  
  sheet = wb.active  
  recipients = []  
  for row in sheet.iter_rows(values_only=True):  
    recipients.append(row)  
  return recipients  
  
def send_emails(sender_email, subject, message, recipients):  
  msg = MIMEMultipart()  
  msg['From'] = sender_email  
  msg['Subject'] = subject  
  msg.attach(MIMEText(message, 'plain'))  
  server = smtplib.SMTP('smtp.gmail.com')  
  server.starttls()  
  server.login(sender_email, 'ujntayukwllonuwx')  
  for recipient in recipients:  
    msg['To'] = recipient  
    server.sendmail(sender_email, recipient, msg.as_string())  
  server.quit()  
  
if __name__ == '__main__':  
  app.run(debug=True)
  
