 
from flask_wtf import FlaskForm  
from wtforms import StringField, FileField, TextAreaField  
from wtforms.validators import DataRequired  
  
class EmailForm(FlaskForm):  
  sender_email = StringField('Sender Email', validators=[DataRequired()])  
  subject = StringField('Subject', validators=[DataRequired()])  
  message = TextAreaField('Message', validators=[DataRequired()])  
  excel_file = FileField('Excel File', validators=[DataRequired()])  
